export class HawkularAnnotationsQueryCtrl {
  constructor() {
  }
}

HawkularAnnotationsQueryCtrl.templateUrl = 'partials/annotations.editor.html';
